export interface PayrollInput {
  id?: string;
  employeeId: string;
  periodStart?: string;
  periodEnd?: string;
  lateMinutes?: number;
  earlyLeaveMinutes?: number;
  absenceDays?: number;
  sickLeaveDays?: number;
  adminLeaveDays?: number;
  unpaidLeaveDays?: number;
  deathLeaveDays?: number;
  unpaidHours?: number;
  overtimeRegularMinutes?: number;
  overtimeWeekendDays?: number;
  penaltyAmount?: number;
  clothingDeduction?: number;
  bonusAdjustment?: number;
  advanceAmount?: number;
  insuranceAmount?: number;
  transportAllowanceOverride?: number;
  notes?: string;
}

export interface PayrollRun {
  id: string;
  runId: string;
  periodStart: string;
  periodEnd: string;
  runDate: string;
  status: string;
  approvalStatus: string;
  totalEmployees: number;
  totalGrossPay: number | string | { $numberDecimal: string };
  totalDeductions: number | string | { $numberDecimal: string };
  totalNetPay: number | string | { $numberDecimal: string };
  notes?: string | null;
}

export interface PayrollItem {
  id: string;
  payrollRunId: string;
  employeeId: string;
  employeeName: string;
  department?: string | null;
  attendanceBasedSalary: number | string | { $numberDecimal: string };
  hoursWorked: number | string | { $numberDecimal: string };
  hourlyRate: number | string | { $numberDecimal: string };
  grossPay: number | string | { $numberDecimal: string };
  totalBonuses: number | string | { $numberDecimal: string };
  totalDeductions: number | string | { $numberDecimal: string };
  netPay: number | string | { $numberDecimal: string };
  /** صافي الراتب مقرباً لأقرب ألف — القيمة المدفوعة فعلياً للموظف */
  netPayRounded: number | string | { $numberDecimal: string };
  /** فرق التقريب = netPayRounded − netPay */
  roundingDifference: number | string | { $numberDecimal: string };
  netPayWithAdvance?: number | string | { $numberDecimal: string };
  earlyLeaveMinutes?: number;
  earlyLeaveDeduction?: number | string | { $numberDecimal: string };
  anomalies?: string[];
}

export interface CalculatePayrollInput {
  periodStart: string;
  periodEnd: string;
  gracePeriodMinutes?: number | string;
  // خصومات الدوام (ستُحسب من سجلات الحضور)
  includeAttendanceDeductions?: boolean;
  // خصومات النقل (ستُحسب من تكاليف الحافلات)
  includeTransportationDeductions?: boolean;
}

export interface PayrollReportTotals {
  totalGrossPay: number;
  totalDeductions: number;
  totalNetPay: number;
}

export interface PayrollReceipt {
  id?: string;
  employeeId: string;
  month: string;
  payrollRunId?: string | null;
  isReceived: boolean;
  receivedAt?: string | null;
  receivedBy?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface PayrollReportResponse {
  month: string;
  period: {
    startDate: string;
    endDate: string;
  };
  runsCount: number;
  latestRun: PayrollRun | null;
  totals: PayrollReportTotals;
  items: PayrollItem[];
}

