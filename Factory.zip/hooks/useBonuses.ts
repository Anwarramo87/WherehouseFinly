import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { toast } from "react-hot-toast";
import apiClient from "@/lib/api-client";
import { Bonus, BonusInput } from "@/types/bonus";
import { QUERY_GC_TIME, QUERY_STALE_TIME } from "@/lib/query-cache";
import { getApiErrorMessage as getErrorMessage } from "@/lib/http/error";
import { queryKeys } from "@/lib/query-keys";

export const useBonuses = (params?: { employeeId?: string; period?: string }) => {
  const queryClient = useQueryClient();
  const router = useRouter();

  const currentPeriod = new Date().toISOString().slice(0, 7);
  const isPastPeriod = params?.period ? params.period < currentPeriod : false;

  const bonusesQuery = useQuery<Bonus[]>({
    queryKey: queryKeys.bonuses.list(params?.employeeId, params?.period),
    queryFn: async () => {
      const res = await apiClient.get("/bonuses", {
        params: {
          employeeId: params?.employeeId,
          period: params?.period,
          limit: 500,
        },
      });

      const data = res.data;

      if (Array.isArray(data)) return data;
      if (data && Array.isArray(data.data)) return data.data;
      if (data && Array.isArray(data.rewards)) return data.rewards;
      if (data && Array.isArray(data.bonuses)) return data.bonuses;

      return [];
    },
    staleTime: isPastPeriod ? 10 * 60_000 : QUERY_STALE_TIME.FAST,
    gcTime: QUERY_GC_TIME.RELAXED,
  });

  const createBonus = useMutation({
    mutationFn: async (payload: BonusInput) => {
      const data = {
        employeeId: payload.employeeId,
        bonusAmount: Number(payload.bonusAmount || 0),
        bonusReason: payload.bonusReason,
        assistanceAmount: Number(payload.assistanceAmount || 0),
        period: payload.period,
      };
      return await apiClient.post("/bonuses", data);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: queryKeys.bonuses.all, exact: false });
      await queryClient.invalidateQueries({ queryKey: queryKeys.discounts.all, exact: false });
      await queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.all, exact: false });
      router.refresh();
      toast.success("تمت إضافة المكافأة بنجاح");
    },
    onError: (error: unknown) => {
      toast.error(getErrorMessage(error, "فشل إضافة المكافأة"));
    },
  });

  const updateBonus = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<BonusInput> }) => {
      const payload = {
        bonusAmount: data.bonusAmount !== undefined ? Number(data.bonusAmount) : undefined,
        bonusReason: data.bonusReason,
        assistanceAmount:
          data.assistanceAmount !== undefined ? Number(data.assistanceAmount) : undefined,
        period: data.period,
      };
      return await apiClient.put(`/bonuses/${id}`, payload);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: queryKeys.bonuses.all, exact: false });
      await queryClient.invalidateQueries({ queryKey: queryKeys.discounts.all, exact: false });
      await queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.all, exact: false });
      router.refresh();
      toast.success("تم تحديث المكافأة");
    },
    onError: (error: unknown) => {
      toast.error(getErrorMessage(error, "فشل تحديث المكافأة"));
    },
  });

  const deleteBonus = useMutation({
    mutationFn: async (id: string) => {
      return await apiClient.delete(`/bonuses/${id}`);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: queryKeys.bonuses.all, exact: false });
      await queryClient.invalidateQueries({ queryKey: queryKeys.discounts.all, exact: false });
      await queryClient.invalidateQueries({ queryKey: queryKeys.dashboard.all, exact: false });
      router.refresh();
      toast.success("تم نقل المكافأة إلى سلة المهملات");
    },
    onError: (error: unknown) => {
      toast.error(getErrorMessage(error, "فشل حذف المكافأة"));
    },
  });

  return {
    ...bonusesQuery,
    createBonus,
    updateBonus,
    deleteBonus,
  };
};
